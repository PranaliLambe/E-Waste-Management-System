import mysql from 'mysql'

export const connection = mysql.createConnection({
    host: 'localhost',
    port: 3306,
    database: 'e-waste',
    user: 'root',
    password: 'root'
})

connection.connect()
