import express from 'express'
import { getCurrentLoggedInUser, getAllUser, userSignUp } from '../controller/user.controller.js';
export const userRouter = express.Router()

userRouter.get('/all', getAllUser)
userRouter.post('/currentLoggedInUser', getCurrentLoggedInUser)  // login
userRouter.post('/create', userSignUp)  // sign up
