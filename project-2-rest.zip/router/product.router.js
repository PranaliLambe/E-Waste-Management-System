import express from 'express'
const productRouter = express.Router()
import {
    addProductToWishlist, getAllProductToWishlistByUserId, getAllNearByCenter,
    getAllProductFromWishlistByCollectorId, createProduct,
    getAllProduct, isProductInCartByProductIdAndUserId, getAllArrivedProductsById,
    productAcceptedByCollector, getAllRejectedProductsFromCollectorByGodownId,
    productRejectedByCollector,
    getAllAddToCartProductsById
}
    from '../controller/product.controller.js';

productRouter.post('/wishlist/create', addProductToWishlist)
productRouter.get('/wishlist/all/:id', getAllProductToWishlistByUserId)
productRouter.get('/nearByCenter', getAllNearByCenter)
productRouter.get('/wishlist/all/byCollector/:collectorId', getAllProductFromWishlistByCollectorId)
productRouter.get('/all', getAllProduct)
productRouter.post('/addToCart', isProductInCartByProductIdAndUserId)
productRouter.post('/create', createProduct)
productRouter.get('/allArrivedProducts/:id', getAllArrivedProductsById)
productRouter.put('/acceptedByCollector/:productId', productAcceptedByCollector)
productRouter.put('/rejectedByCollector/:productId', productRejectedByCollector)
productRouter.get('/allProductsFromCollector/:godownId', getAllRejectedProductsFromCollectorByGodownId)
productRouter.get('/allAddToCartProducts/:id', getAllAddToCartProductsById)

export default productRouter
