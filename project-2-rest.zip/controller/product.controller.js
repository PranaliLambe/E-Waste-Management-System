import {connection} from '../config/db.js'

const addProductToWishlist = (req, res) => {
    const { name, expectedPrize, quentity, nearByCenter, userId } = req.body

    connection.query('INSERT INTO WISHLIST SET NAME = ?, EXPECTEDPRIZE = ?, QUENTITY = ?, NEARBYCENTERID = ? , USERID = ?',
        [name, expectedPrize, quentity, nearByCenter, userId],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(201).send(result)
        })
}


const getAllProductToWishlistByUserId = (req, res) => {
    console.log(req.params.id);
    connection.query('SELECT * FROM WISHLIST WHERE USERID = ? ',
        req.params.id,
        (error, result) => {
            console.log(error);
            res.send(result)
        })
}

const getAllNearByCenter = (req, res) => {
    connection.query('SELECT name as NAME, id as ID FROM NEARBYCENTERMASTER ',
        req.params.id,
        (error, result) => {
            res.send(result)
        })
}

const getAllProductFromWishlistByCollectorId = (req, res) => {
    console.log('HI----------');
    connection.query('SELECT WL.NAME AS PRODUCTNAME, WL.QUENTITY, WL.EXPECTEDPRIZE, ' +
        'UT.FIRSTNAME AS USERFIRSTNAME, UT.LASTNAME AS USERLASTNAME, ' +
        'UT.CONTACTNUMBER AS USERCONTACTNUMBER FROM USERMASTER UM INNER JOIN ' +
        'NEARBYCENTERMASTER NBC ON UM.ID = NBC.COLLECTORID INNER JOIN WISHLIST WL ' +
        'ON NBC.ID = WL.NEARBYCENTERID INNER JOIN USERTRANSACTION UT ON UT.USERID = WL.USERID ' +
        'WHERE UM.ID = ?',
        req.params.collectorId,
        (error, result) => {
            console.log(error);
            console.log(result);
            res.send(result)
        })
}

const getAllProduct = (req, res) => {
    connection.query('SELECT * from productmaster where active = ? ',
        'Y',
        (error, result) => {
            console.log(error)
            res.send(result)
        })
}

// const addToCart = async (req, res) => {
//     let result = await isProductInCartByProductIdAndUserId(req.body)
//     console.log(result);
// }

const isProductInCartByProductIdAndUserId = (req, res) => {
    const { productId, userId } = req.body
    // console.log(productId, userId);
    connection.query('SELECT * FROM CARTMASTER WHERE PRODUCTID = ? AND USERMASTERID = ?',
        [productId, userId],
        (error, result) => {
            // console.log(error)
            console.log(result)
            if (result.length > 0) {
                updateToCart(res, productId, userId, result[0].productcount)
            } else {
                addToCart(res, productId, userId)
            }
        })
}

const updateToCart = (res, productId, userId, currentProductCount) => {
    // console.log('update cart', currentProductCount);
    connection.query('UPDATE CARTMASTER SET PRODUCTCOUNT = ? WHERE PRODUCTID = ? AND USERMASTERID = ?',
        [currentProductCount + 1, productId, userId],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(200).send(result)
        })
}

const addToCart = (res, productId, userId) => {
    // console.log('add to  cart')
    connection.query('INSERT INTO CARTMASTER SET PRODUCTCOUNT = ?, PRODUCTID = ?, USERMASTERID = ?',
        [1, productId, userId],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(201).send(result)
        })
}

const createProduct = (req, res) => {
    // console.log('add to  cart')
    const { prize, name, nearByCenterId, numberOfYearsUsed, userId } = req.body
    connection.query('INSERT INTO PRODUCTMASTER SET NAME = ?, PRICE = ?, ACTIVE = ?, NUMBEROFYEARSUSED = ?',
        [name, prize, 'N', numberOfYearsUsed],
        (error, result) => {
            console.log(error)
            console.log(result)
            let productId = result.insertId
            if (result.affectedRows === 1) {
                createProductInTransaction(res, nearByCenterId, userId, productId)
            }
        })
}

const createProductInTransaction = (res, nearByCenterId, userId, productId) => {
    connection.query('INSERT INTO PRODUCTTRANSACTION SET PRODUCTID = ?, USERMASTERID = ?, NEARBYCENTERMASTERID = ?',
        [productId, userId, nearByCenterId],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(201).send(result)
        })
}

const getAllArrivedProductsById = (req, res) => {
    connection.query('SELECT PM.id, PM.name, PM.originalprice, PM.price FROM PRODUCTMASTER PM ' +
        'INNER JOIN PRODUCTTRANSACTION PT ON PM.ID = PT.PRODUCTID INNER JOIN NEARBYCENTERMASTER NBC ' +
        'ON PT.NEARBYCENTERMASTERID = NBC.ID WHERE PM.ACTIVE = ? AND NBC.COLLECTORID = ? ',
        ['N', req.params.id],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(200).send(result)
        })
}

const productAcceptedByCollector = (req, res) => {
    connection.query('UPDATE PRODUCTMASTER SET ACTIVE = ? WHERE ID = ? ',
        ['Y', req.params.productId],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(200).send(result)
        })
}

const productRejectedByCollector = (req, res) => {
    connection.query('UPDATE PRODUCTMASTER SET ACTIVE = ? WHERE ID = ? ',
        ['R', req.params.productId],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(200).send(result)
        })
}

const getAllRejectedProductsFromCollectorByGodownId = (req, res) => {
    connection.query('SELECT pm.name, pm.price, pm.originalprice, pm.numberOfYearsUsed ' +
        'FROM nearbycentermaster nbc inner join producttransaction pt on nbc.id = pt.nearByCenterMasterId ' +
        'inner join PRODUCTMASTER pm on pt.productId = pm.id ' +
        'where nbc.godownheadId = ? and pm.active = ?',
        [req.params.godownId, 'R'],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(200).send(result)
        })
}

const getAllAddToCartProductsById = (req, res) => {
    connection.query('SELECT PM.id, PM.name, PM.originalprice, PM.price, CM.productcount ' +
        'FROM CARTMASTER CM INNER JOIN USERMASTER UM ' +
        'ON CM.USERMASTERID = UM.ID INNER JOIN PRODUCTMASTER PM ' +
        'ON CM.PRODUCTID = PM.ID WHERE UM.ID =  ?',
        [req.params.id],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(200).send(result)
        })
}

export {
    addProductToWishlist, getAllProductToWishlistByUserId, getAllNearByCenter,
    getAllProductFromWishlistByCollectorId, getAllProduct, addToCart,
    isProductInCartByProductIdAndUserId, createProduct, getAllArrivedProductsById,
    productAcceptedByCollector, productRejectedByCollector,
    getAllRejectedProductsFromCollectorByGodownId,
    getAllAddToCartProductsById
}
