import {connection} from "../config/db.js"

const getCurrentLoggedInUser = (req, res) => {
    console.log(req)
    connection.query(
        'SELECT UM.EMAILID, UM.ROLE, UM.ID as USERID, UT.FIRSTNAME, ' +
        'UT.LASTNAME,UT.CONTACTNUMBER, LAM.ADDRESSLINE as LOCAL_ADDRESS_LINE, ' +
        'LAM.CITY as LOCAL_CITY, LAM.POSTELCODE as LOCAL_POSTELCODE, ' +
        'LAM.STATE AS LOCAL_STATE, LAM.COUNTRY AS LOCAL_COUNTRY, ' +
        'PAM.ADDRESSLINE as PERMANANT_ADDRESS_LINE, ' +
        'PAM.CITY as PERMANANT_CITY, ' +
        'PAM.STATE AS PERMANANT_STATE, PAM.COUNTRY AS PERMANANT_COUNTRY ' +
        'FROM USERMASTER UM INNER JOIN USERTRANSACTION UT ' +
        'ON UM.ID = UT.USERID INNER JOIN ADDRESSMASTER AM ' +
        'ON UT.ADDRESSID = AM.ID INNER JOIN LOCALADDRESSMASTER LAM ' +
        'ON AM.LOCALADDRESSID = LAM.ID INNER JOIN PERMANANTADDRESSMASTER PAM ' +
        'ON AM.PERMANANATADDRESSID = PAM.ID WHERE EMAILID = ? AND PASSWORD = ?',
        [req.body.emailID, req.body.password],
        (error, result) => {
            console.log(result)
            console.log(error)
            res.send(result[0])
        })
}

const userSignUp = async (req, res) => {
    const { addressLine, city, pinCode, state, country, emailId, role,
        firstName, lastName, contactNumber } = req.body

    // console.log(addressLine, city, pinCode, state, country, emailId, role,
    //     firstName, lastName, contactNumber);
    let localAddress = {
        addressLine: addressLine,
        city: city,
        postalCode: pinCode,
        state: state,
        country: country
    }

    let locaAddressId = await createLocalAddress(localAddress)
    let permanentAddressId = await createPermanentAddress(localAddress)
    let addressId = await createAddress(locaAddressId, permanentAddressId)
    let userId = await createUser(emailId, 'Welcome@123', role)
    createUserTransaction(userId, addressId, firstName, lastName, contactNumber, res)
}

const createLocalAddress = (localAddress) => {
    const { addressLine, city, postalCode, state, country } = localAddress
    return new Promise((resolve, reject) => {
        connection.query('INSERT INTO LOCALADDRESSMASTER SET ADDRESSLINE = ?, '
            + 'CITY = ?, POSTELCODE = ?, STATE = ?, COUNTRY = ?',
            [addressLine, city, postalCode, state, country],
            (error, result) => {
                console.log(error)
                resolve(result.insertId)
            })
    })
}

const createPermanentAddress = (permanentAddress) => {
    const { addressLine, city, postalCode, state, country } = permanentAddress
    return new Promise((resolve, reject) => {
        connection.query('INSERT INTO PERMANANTADDRESSMASTER SET ADDRESSLINE = ?, '
            + 'CITY = ?, POSTELCODE = ?, STATE = ?, COUNTRY = ?',
            [addressLine, city, postalCode, state, country],
            (error, result) => {
                console.log(error)
                resolve(result.insertId)
            })
    })
}

const createAddress = (locaAddressId, permanentAddressId) => {
    return new Promise(resolve => {
        connection.query('INSERT INTO ADDRESSMASTER SET LOCALADDRESSID = ?, PERMANANATADDRESSID = ? ',
            [locaAddressId, permanentAddressId],
            (error, result) => {
                console.log(error)
                resolve(result.insertId)
            })
    })
}

const createUser = (emailId, password, role) => {
    return new Promise(resolve => {
        connection.query('INSERT INTO USERMASTER SET EMAILID = ?, PASSWORD = ?, ROLE = ? ',
            [emailId, password, role],
            (error, result) => {
                console.log(result)
                console.log(error);
                resolve(result.insertId)
            })
    })
}

const createUserTransaction = (userId, addressId, firstName,
    lastName, contactNumber, res) => {
    connection.query('INSERT INTO USERTRANSACTION SET USERID = ?, ADDRESSID = ?, FIRSTNAME = ?, LASTNAME = ?, CONTACTNUMBER = ?',
        [userId, addressId, firstName, lastName, contactNumber],
        (error, result) => {
            console.log(error)
            console.log(result)
            res.status(201).send('user created successfully')
        })
}

const getAllUser = (req, res) => {
    connection.query('select * from usertransaction',
        (error, result) => {
            res.send(result)
        })
}

const updateUser = () => {
    connection.query('update ',
        (error, result) => {
            res.send(result)
        })
}

export {
    getCurrentLoggedInUser,
    getAllUser,
    userSignUp
}
