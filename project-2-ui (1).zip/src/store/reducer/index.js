import { combineReducers } from "redux";
import notificationReducer from "./NotificationReducer";
import allUserReducer from "./user/user-index";

const allReducer = combineReducers({
    notificationReducer: notificationReducer,
    allUserReducer: allUserReducer
})

export default allReducer
