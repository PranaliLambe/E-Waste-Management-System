const notificationReducer = (state = '', action) => {
    switch (action.type) {
        case 'SHOW-NOTIFICATION':
            return state = action
        case 'HIDE-NOTIFICATION':
            return state = action
        default:
            return state
    }
}

export default notificationReducer
