import { combineReducers } from "redux";
import userReducer from './UserReducer'

const allUserReducer = combineReducers({
    userReducer: userReducer
})

export default allUserReducer
