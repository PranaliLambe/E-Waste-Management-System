const userReducer = (state = '', action) => {
    switch (action.type) {
        case 'SET-LOGIN-USER':
            return state = action
        case 'REMOVE-LOGIN-USER':
            return state = action
        default:
            return state
    }
}

export default userReducer
