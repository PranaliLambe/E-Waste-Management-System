const setLoginUser = (currentUser) => {
    return {
        type: 'SET-LOGIN-USER',
        currentUser: currentUser
    }
}

const removeLoginUser = () => {
    return {
        type: 'REMOVE-LOGIN-USER',
        currentUser: {}
    }
}

export {
    setLoginUser,
    removeLoginUser
}
