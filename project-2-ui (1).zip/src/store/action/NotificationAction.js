const showNotification = (message, severity) => {
    return {
        type: 'SHOW-NOTIFICATION',
        message: message,
        display: true,
        severity: severity
    }
}

const hideNotification = () => {
    return {
        type: 'HIDE-NOTIFICATION',
        message: '',
        display: false,
        severity: 'info'
    }
}

export {
    showNotification,
    hideNotification
}
