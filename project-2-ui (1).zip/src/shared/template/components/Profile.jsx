const Profile = () => {
    return (<>Profile component...</>);
}

export default Profile