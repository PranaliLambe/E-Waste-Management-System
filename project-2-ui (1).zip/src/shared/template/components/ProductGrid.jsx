import React from 'react'

export default function ProductGrid({ allProduct, gridType, setSubmit }) {

    return (
        <div>
            {
                allProduct.map((product) => (
                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <img src="img/5.jpg" alt="" />
                            <div class="caption">
                                <h3>{product.name} </h3>
                                <p><del>Original Price : Rs. {product.originalprice}</del> </p>
                                <p>Price: Rs. {product.price} </p>
                                {
                                    gridType === 'Cart' ?
                                        <p>Quantity: {product.productcount} </p> : ''
                                }
                                {
                                    gridType === 'Products' ?
                                        <p>
                                            <a role="button" class="btn btn-primary btn-block"
                                                onClick={() => setSubmit('AddToCard', product.id, JSON.parse(localStorage.getItem('USER')).USERID)}>
                                                Add to cart
                                            </a>
                                            <a role="button" class="btn btn-success btn-block"
                                                onClick={() => setSubmit('BuyNow', product.id, JSON.parse(localStorage.getItem('USER')).USERID)}>
                                                Buy Now
                                            </a>
                                        </p> : gridType === 'ProductsArrived' ?
                                            <p>
                                                <a role="button" class="btn btn-primary btn-block"
                                                    onClick={() => setSubmit('Accept', product.id)}>
                                                    Accept
                                                </a>
                                                <a role="button" class="btn btn-danger btn-block"
                                                    onClick={() => setSubmit('Reject', product.id)}>
                                                    Reject
                                                </a>
                                            </p> : gridType === 'Cart' ?
                                                <p>
                                                    <a role="button" class="btn btn-success btn-block"
                                                        onClick={() => setSubmit(product.id, JSON.parse(localStorage.getItem('USER')).USERID)}>
                                                        Buy Now
                                                    </a>
                                                </p> : ''
                                }

                            </div>
                        </div>
                    </div>
                ))
            }
        </div >
    )
}
