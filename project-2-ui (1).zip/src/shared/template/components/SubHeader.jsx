const SubHeader = () => {
    return (
        <div className="container" id="content" align="center" style={{ 'marginTop': '100px' }}>
            <div className="jumbotron home-spacer" id="products-jumbotron">
                <h1>Welcome to E-Waste Management</h1>
                <p>We have the best recycled products for you. No need to hunt around, we have all in one place.</p>
            </div>
            <hr />
        </div>
    )
}

export default SubHeader