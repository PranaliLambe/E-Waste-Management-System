import { Snackbar, Alert } from "@mui/material";
import { useSelector, useDispatch } from 'react-redux'
import { hideNotification } from "../../../store/action/NotificationAction";

const Notification = () => {

    const notificationReducer = useSelector(state => state.notificationReducer)
    const dispatch = useDispatch()

    const handleClose = () => {
        dispatch(hideNotification())
    };

    return (
        <>
            <Snackbar
                open={notificationReducer.display}
                autoHideDuration={6000}
                onClose={handleClose}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
                <Alert onClose={handleClose} severity={notificationReducer.severity}>
                    {notificationReducer.message}
                </Alert>
            </Snackbar>
        </>
    );
}

export default Notification
