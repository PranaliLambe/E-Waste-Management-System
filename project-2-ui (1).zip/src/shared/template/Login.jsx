import { useForm } from 'react-hook-form'
import { useHistory } from 'react-router-dom'
import {_checkCurrentUserLogin} from '../../services/LoginService'
import { useDispatch } from 'react-redux'
import { showNotification } from '../../store/action/NotificationAction'
import Header from './Header';
import SubHeader from './components/SubHeader';
import Footer from './Footer';
import { setLoginUser } from '../../store/action/user/UserAction'

function Login() {

    const { register, handleSubmit, formState: { errors }, } = useForm()
    const history = useHistory()
    const dispatch = useDispatch()

    const eventLogger = (e, data) => {
        console.log('Event: ', e);
        console.log('Data: ', data);
    };

    const onSubmit = (data) => {
        console.log(data)
        // dispatch(showNotification('Invalid User Id', 'error'))
        _checkCurrentUserLogin(data).then(result => {
            console.log(result)
            if (result.data === '') {
                dispatch(showNotification('Invalid User Id', 'error'))
            } else {
                dispatch(showNotification('Login Successfully', 'success'))
                // dispatch(setLoginUser(result.data))
                localStorage.setItem('USER', JSON.stringify(result.data))
                history.push('/home/' + result.data.ROLE)
            }
        })
    }

    return (
        <>
            <Header />
            <SubHeader />
            <div className="container-fluid decor_bg" id="content">
                <div className="row4">
                    <div className="container">
                        <div className="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                            <h2>Login</h2>
                            <form>
                                <div className="form-group">
                                    <input type="email" className="form-control" placeholder="Email"
                                        name="e-mail"
                                        {...register('emailID', { required: true })} />
                                    {errors.emailID && <p className="error">Email Id is required.</p>}
                                </div>
                                <div className="form-group">
                                    <input type="password" className="form-control" placeholder="Password"
                                        name="password"
                                        {...register('password', { required: true })} />
                                    {errors.password && <p className="error">Password is required.</p>}
                                </div>

                                <button type="submit" name="submit" className="btn btn-primary"
                                    onClick={handleSubmit(onSubmit)}>
                                    Submit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <br />
            <br />
            <br/>
            <br />
            <Footer />
        </>
    );
}

export default Login;