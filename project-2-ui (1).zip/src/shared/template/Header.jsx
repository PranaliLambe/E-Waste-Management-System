import { Link } from 'react-router-dom'
import { useHistory, useLocation } from 'react-router-dom'
const Header = () => {
    const history = useHistory()
    const location = useLocation()

    const navigateToProfile = (subMenu) => {
        console.log(location.pathname.split('/', 3)[2]);
        let role = location.pathname.split('/', 3)[2]
        history.push(subMenu)
    }
    return (
        
        <div className="navbar navbar-inverse navbar-fixed-top">
            <div className="container e-header">
                <div className="navbar-header ">
                    <button type="button" className="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span className="icon-bar"></span>
                        <span className="icon-bar"></span>
                        <span className="icon-bar"></span>
                    </button>
                    <Link to="/home"> 
                    <a className="navbar-brand" >Helping Nature</a></Link>
                </div>
                
                  <div classname="e-header-right"> 
                      
                     <ul className="nav navbar-nav navbar-right"> 
                        <li><Link to="/signUp" ><span className="glyphicon glyphicon-user" ></span> Sign Up</Link></li>
                        <li><Link to="/login" ><span className="glyphicon glyphicon-log-in"></span> Login</Link></li>
                        <li><Link to="/feedback" ><span className="glyphicon glyphicon-thumbs-up"></span> Our Feedback</Link></li>
                     </ul> 
                 </div>
            </div>
        </div>
    )
}

export default Header