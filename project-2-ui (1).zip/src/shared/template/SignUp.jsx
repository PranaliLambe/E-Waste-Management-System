import SubHeader from "./components/SubHeader";
import Footer from "./Footer";
import Header from "./Header";
import { useForm } from 'react-hook-form'
import { _createUser } from "../../services/LoginService";
import React from 'react'
import { showNotification } from "../../store/action/NotificationAction";
import { useDispatch } from 'react-redux'
import { useHistory } from 'react-router-dom'

function SignUp() {
    const { register, handleSubmit, formState: { errors }, } = useForm()
    const [allRole] = React.useState([
        { label: 'User', value: 'user' },
        { label: 'Collector', value: 'collector' },
        { label: 'Go Down Head', value: 'godown' }
    ])
    const history = useHistory()
    const dispatch = useDispatch()
    const onSubmit = (data) => {
        console.log(data)
        // dispatch(showNotification('Invalid User Id', 'error'))
        data.role = 'user'
        _createUser(data).then(result => {
            console.log(result)
            if (result.data === 'user created successfully') {
                dispatch(showNotification('Sign Up Successfully', 'success'))
                history.push('/login')
            } else {
                dispatch(showNotification('Please try again !', 'error'))
            }
        })
    }

    return (
        <>
            <Header />
            <SubHeader />
            <div class="container">
                <h2>SIGN UP</h2>
                <form>
                    <hr />
                    <div style={{ 'display': 'flex', 'flexDirection': 'row-reverse', 'top': 0 }}>
                        <button type="submit" name="submit" class="btn btn-primary"
                            onClick={handleSubmit(onSubmit)}>
                            Submit
                        </button>
                    </div>
                    <br />
                    <div class="row">
                        <div class="form-group col-md-3">
                            <input class="form-control w-100" placeholder="First Name"
                                name="firstName"
                                {...register('firstName', { required: true })} />
                            {errors.firstName && <p className="error">First Name is required.</p>}
                        </div>
                        <div class="form-group col-md-3">
                            <input class="form-control w-100" placeholder="Last Name"
                                name="lastName" {...register('lastName', { required: true })} />
                            {errors.lastName && <p className="error">Last Name is required.</p>}
                        </div>
                        <div class="form-group col-md-3">
                            <input class="form-control w-100" placeholder="Email ID"
                                name="emailId" {...register('emailId', { required: true })} />
                            {errors.emailId && <p className="error">Email ID is required.</p>}
                        </div>
                        <div class="form-group col-md-3">
                            <input class="form-control w-100" placeholder="Contact Number"
                                name="contactNumber" {...register('contactNumber', { required: true })} />
                            {errors.contactNumber && <p className="error">Contact Number is required.</p>}
                        </div>
                    </div>
                    <div class="row">
                        {/* <Box >
                            <FormControl className="mt-1" style={{ 'width': '230px' }}>
                                <InputLabel id="demo-simple-select-label">Role</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    {...register('role', { required: true })}
                                    name="role"
                                    label="Role">
                                    {
                                        allRole && allRole.map((role, index) => (
                                            <MenuItem value={role.value} key={index}>
                                                {role.label}
                                            </MenuItem>
                                        ))
                                    }
                                </Select>
                                {errors.nearByCenterId && <p className="error">Near By Center is required.</p>}
                            </FormControl>
                        </Box> */}
                        <div class="form-group col-md-12">
                            <input class="form-control w-100" placeholder="Address Line"
                                name="addressLine" {...register('addressLine', { required: true })} />
                            {errors.addressLine && <p className="error">Address Line is required.</p>}
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-3">
                            <input class="form-control w-100" placeholder="City"
                                name="city" {...register('city', { required: true })} />
                            {errors.city && <p className="error">City is required.</p>}
                        </div>
                        <div class="form-group col-md-3">
                            <input class="form-control w-100" placeholder="State"
                                name="state" {...register('state', { required: true })} />
                            {errors.state && <p className="error">State is required.</p>}
                        </div>
                        <div class="form-group col-md-3">
                            <input class="form-control w-100" placeholder="Country"
                                name="country" {...register('country', { required: true })} />
                            {errors.country && <p className="error">Country is required.</p>}
                        </div>
                        <div class="form-group col-md-3">
                            <input class="form-control w-100" placeholder="Pin Code"
                                name="pinCode" {...register('pinCode', { required: true })} />
                            {errors.pinCode && <p className="error">Pin Code is required.</p>}
                        </div>
                    </div>
                </form>
            </div >
            <br />
            <br />
            <br />
            <br />
            <br />
            <Footer />
        </>
    );
}

export default SignUp;