import React from 'react';
import Collector from '../../components/Collector/Collector';
import GodownHead from '../../components/GodownHead/GodownHead';
import User from '../../components/User/User';
import Footer from './Footer';
import Header from './Header';
import './Template.css'
import { Switch,  Route } from 'react-router-dom'

const Home = () => {
    return (
        <>
            <Header />
            <Switch>
            
                <Route path="/home/user" component={User} />
                <Route path="/home/collector" component={Collector} />
                <Route path="/home/godownHead" component={GodownHead} />
            </Switch>
            <Footer />
        </>
    );
}

export default Home;