import Header from "./Header";
import SubHeader from "./components/SubHeader"
import Footer from "./Footer";
import Products from "../../components/User/Products";
import { Switch,Route } from 'react-router-dom'

function Shop() {
    return (
        <>
            <Header />
            <SubHeader />
            {/* Shop Component */}
            <Switch>
                <Route path="/home/shop" component={Products}/>
            </Switch>
            <Footer />
        </>
    );
}

export default Shop;