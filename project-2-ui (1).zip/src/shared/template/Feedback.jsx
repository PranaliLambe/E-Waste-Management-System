import SubHeader from "./components/SubHeader";
import Footer from "./Footer";
import Header from "./Header";

function Feedback() {
    return (
        <>
        <Header/>
        <SubHeader/>
        <div class="container">
            <h2>Our Feedbacks</h2>
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Customer Name</th>
                        <th>Feedback</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>John</td>
                        <td>Best recycled laptop under this Price.... Must Buy</td>
                    </tr>
                    <tr>
                        <td>Mary</td>
                        <td>You must go for watch section...This is a very good product...I am very happy with prodcut quality</td>
                    </tr>
                    <tr>
                        <td>Jyuhi</td>
                        <td>This organization is doing very great work... #HelpingNature</td>
                    </tr>
                </tbody>
            </table>
            <div class="container-fluid decor_bg" id="content">
                <div class="row4">
                    <div class="container">
                        <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                            <h2>Add your feedback...</h2>
                            <form action="signup_script.html" method="POST">
                                <div class="form-group">
                                    <input class="form-control" placeholder="Name" name="name" required />
                                </div>
                                <div class="form-group">
                                    <input type="feedback" class="form-control" placeholder="Feedback" name="feedback" required />
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Footer/>
        </>
    );
}

export default Feedback;