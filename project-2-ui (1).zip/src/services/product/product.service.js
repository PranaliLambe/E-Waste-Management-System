import axios from 'axios'

const url = 'http://localhost:7070/product'

const _addProductToWishlistByUserId = (currentWishlist) => {
    return axios.post(url + '/' + 'wishlist' + '/' + 'create', currentWishlist)
}

const _getAllProductToWishlistByUserId = (UserId) => {
    return axios.get(url + '/' + 'wishlist' + '/' + 'all' + '/' + UserId)
}

const _getAllNearByCenter = () => {
    return axios.get(url + '/' + 'nearByCenter')
}

const _getAllProductFromWishlistByCollectorId = (collectorId) => {
    return axios.get(url + '/' + 'wishlist' + '/' + 'all' + '/' + 'byCollector' + '/' + collectorId)
}

const _getAllProduct = () => {
    return axios.get(url + '/' + 'all')
}

const _addToCart = (productId, userId) => {
    let request = {
        productId: productId,
        userId: userId
    }
    return axios.post(url + '/' + 'addToCart', request)
}

const _createProduct = (productDetails) => {
    return axios.post(url + '/' + 'create', productDetails)
}

const _getAllArrivedProductsById = (collectorId) => {
    return axios.get(url + '/' + 'allArrivedProducts' + '/' + collectorId)
}

const _productAcceptedByCollector = (productId) => {
    return axios.put(url + '/' + 'acceptedByCollector' + '/' + productId)
}

const _productRejectedByCollector = (productId) => {
    return axios.put(url + '/' + 'rejectedByCollector' + '/' + productId)
}

const _getAllRejectedProductsFromCollectorByGodownId = (godownId) => {
    return axios.get(url + '/' + 'allProductsFromCollector' + '/' + godownId)
}

const _getAllAddToCartProductsById = (id) => {
    return axios.get(url + '/' + 'allAddToCartProducts' + '/' + id)
}

export {
    _addProductToWishlistByUserId,
    _getAllProductToWishlistByUserId,
    _getAllNearByCenter,
    _getAllProductFromWishlistByCollectorId,
    _getAllProduct,
    _addToCart,
    _createProduct,
    _getAllArrivedProductsById,
    _productAcceptedByCollector,
    _productRejectedByCollector,
    _getAllRejectedProductsFromCollectorByGodownId,
    _getAllAddToCartProductsById
}
