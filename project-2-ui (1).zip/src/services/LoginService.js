import axios from 'axios'

const devUrl = 'http://localhost:7070/user'

const _checkCurrentUserLogin = (user) => {
    return axios.post(devUrl + '/' + 'currentLoggedInUser', user)
}

const _createUser = (user) => {
    return axios.post(devUrl + '/' + 'create', user)
}

export {
    _checkCurrentUserLogin, _createUser
}
