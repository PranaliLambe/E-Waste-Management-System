import { useHistory, useLocation } from 'react-router-dom'

function CollectorHome() {

    const history = useHistory()
    const location = useLocation()

    const navigateToProfile = (subMenu) => {
        console.log(location.pathname.split('/', 3)[2]);
        let role = location.pathname.split('/', 3)[2]
        history.push('/home/' + role + '/' + subMenu)
    }
    return (
        <>
                <div className="row text-center" id="collectors">
                    <div className="col-md-3 col-sm-6 home-feature">
                        <div className="thumbnail">
                            <div className="caption">
                                <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('profile')}>Profile</a></h3>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-3 col-sm-6 home-feature">
                        <div className="thumbnail">
                            <div className="caption">
                                <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('callMessageFromUser')}>Call/Message from User</a></h3>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-3 col-sm-6 home-feature">
                        <div className="thumbnail">
                            <div className="caption">
                                <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('recycledProducts')}>Recycled Products</a></h3>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="row text-center" id="cameras">
                    <div className="col-md-3 col-sm-6 home-feature">
                        <div className="thumbnail">
                            <div className="caption">
                                <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('toBeRecycledProducts')}>To be Recycled Products</a></h3>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-3 col-sm-6 home-feature">
                        <div className="thumbnail">
                            <div className="caption">
                                <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('callMessageToGodown')}>Call/Message to Go-Down</a></h3>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-3 col-sm-6 home-feature">
                        <div className="thumbnail">
                            <div className="caption">
                                <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('timeSchedule')}>Time Schedule</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row text-center" id="cameras">
                    <div className="col-md-3 col-sm-6 home-feature">
                        <div className="thumbnail">
                            <div className="caption">
                                <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('products-arrived')}>Products Arrived</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
        </>
    );
}

export default CollectorHome;