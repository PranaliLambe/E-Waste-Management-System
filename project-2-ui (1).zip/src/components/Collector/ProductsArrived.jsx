import React from 'react'
import { _getAllArrivedProductsById, _productAcceptedByCollector, _productRejectedByCollector } from '../../services/product/product.service'
import ProductGrid from '../../shared/template/components/ProductGrid'
import { useHistory } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { showNotification } from '../../store/action/NotificationAction';

export const ProductsArrived = () => {
    const [allProduct, setAllProduct] = React.useState([])
    const history = useHistory()
    const dispatch = useDispatch()
    // const [submit, setSubmit] = React.useState()

    React.useEffect(() => {
        getAllArrivedProductsById(JSON.parse(localStorage.getItem('USER')).USERID)
    }, [])

    const getAllArrivedProductsById = (collectorId) => {
        _getAllArrivedProductsById(collectorId).then(result => setAllProduct(result.data))
    }
    const setSubmit = (buttonLabel, productId) => {
        if (buttonLabel === 'Accept') {
            _productAcceptedByCollector(productId).then(result => {
                if (result.status === 200) {
                    dispatch(showNotification('Product Accepted', 'success'))
                    history.push('../collector/recycledProducts')
                }
            })
        } else if (buttonLabel === 'Reject') {
            _productRejectedByCollector(productId).then(result => {
                if (result.status === 200) {
                    getAllArrivedProductsById(JSON.parse(localStorage.getItem('USER')).USERID)
                    dispatch(showNotification('Product Rejected', 'error'))
                    history.push('../collector/toBeRecycledProducts')
                }
            })
        }
    }

    return (
        <div class="container">
            <ProductGrid allProduct={allProduct} gridType="ProductsArrived"
                setSubmit={(buttonLabel, productId) => setSubmit(buttonLabel, productId)} />
        </div>
    )
}
