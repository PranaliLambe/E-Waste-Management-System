import SubHeader from "../../shared/template/components/SubHeader";
import { Switch,Route } from 'react-router-dom'
import Header from "../../shared/template/Header";
import Footer from "../../shared/template/Footer";

import CollectorHome from './CollectorHome';
import Profile from './Profile'
import CallMessageFromUser from './CallMessageFromUser'
import CallMessageToGodown from './CallMessageToGodown';
import ToBeRecycledProducts from './ToBeRecycledProducts';
import RecycledProducts from './RecycledProducts';
import TimeSchedule from './TimeSchedule';
import { ProductsArrived } from "./ProductsArrived";

const Collector = () => {
    return (
        <>
            <div>    
                <Header />
                <SubHeader />
                <Switch>
                    <Route path="/home/collector" component={CollectorHome} exact />
                    <Route path="/home/collector/profile" component={Profile} />
                    <Route path="/home/collector/callMessageToGodown" component={CallMessageToGodown} />
                    <Route path="/home/collector/callMessageFromUser" component={CallMessageFromUser} />
                    <Route path="/home/collector/toBeRecycledProducts" component={ToBeRecycledProducts} />
                    <Route path="/home/collector/recycledProducts" component={RecycledProducts} />
                    <Route path="/home/collector/timeSchedule" component={TimeSchedule} />
                    <Route path="/home/collector/products-arrived" component={ProductsArrived} />
                </Switch>
                <Footer />
            </div>
        </>
    );
}


export default Collector