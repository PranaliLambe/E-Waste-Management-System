function ToBeRecycledProducts() {
    return (
        <>
            <div class="container">

                <div class="row3 text-center" id="users">

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Mobile Phones</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Ear Phones</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Laptops</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Oven</a></h3>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row3 text-center" id="cameras">

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Refrigerator</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Television</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Watches</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Keyboards</a></h3>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row3 text-center" id="cameras">

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Speakers</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Washing Machines</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Projectors</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Fans</a></h3>
                            </div>
                        </div>
                    </div>

                </div>
                
            </div>
        </>
    );
}

export default ToBeRecycledProducts;