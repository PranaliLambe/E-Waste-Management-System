function TimeSchedule() {
    return (
        <>Time Schedule Component</>
    );
}

export default TimeSchedule;