function Profile() {
    return (
        <div class="container">
            <h2>Your Profile</h2>
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Information</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Name</td>
                        <td>John Goe</td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td>Sector No. 13, North Paris</td>
                    </tr>
                    <tr>
                        <td>Contact Number</td>
                        <td>4563208791</td>
                    </tr>
                </tbody>
            </table>
            <div class="container-fluid decor_bg" id="content">
                <div class="row">
                    <div class="container">
                        <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                            <h2>Update your profile</h2>
                            <form action="signup_script.html" method="POST">
                                <div class="form-group">
                                    <input class="form-control" placeholder="Add Details" name="adddetails" required />
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Profile;