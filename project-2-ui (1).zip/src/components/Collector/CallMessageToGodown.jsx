function CallMessageToGodown() {
    return (
        <>Call Message to godown Component</>
    );
}

export default CallMessageToGodown;