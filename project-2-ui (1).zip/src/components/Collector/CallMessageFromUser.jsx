import React from 'react'
import { _getAllProductFromWishlistByCollectorId } from '../../services/product/product.service'

function CallMessageFromUser() {

    const [allWishlistProduct, setAllWishlistProduct] = React.useState([])

    React.useEffect(() => {
        _getAllProductFromWishlistByCollectorId(JSON.parse(localStorage.getItem('USER')).USERID)
            .then(result => {
                setAllWishlistProduct(result.data)
            })
    }, [])

    return (
        <>
            <div class="container">
                <table className="table table-hover">
                    <thead>
                        <tr>
                            <th>Name of Product</th>
                            <th>Quantity</th>
                            <th>Prize Expected</th>
                            <th>User First Name</th>
                            <th>User Last Name</th>
                            <th>User Contact Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            allWishlistProduct && allWishlistProduct.map((product, index) => (
                                <tr key={index}>
                                    <td>{product.PRODUCTNAME}</td>
                                    <td>{product.QUENTITY}</td>
                                    <td>{product.EXPECTEDPRIZE}</td>
                                    <td>{product.USERFIRSTNAME}</td>
                                    <td>{product.USERLASTNAME}</td>
                                    <td>{product.USERCONTACTNUMBER}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
                <br />
            <br />
            <br/>
            <br />
            </div>
        </>
    );
}

export default CallMessageFromUser;