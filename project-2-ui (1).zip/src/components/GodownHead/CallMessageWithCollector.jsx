function CallMessageWithCollector() {
    return (
        <>Call Message with collector Component</>
    );
}

export default CallMessageWithCollector;