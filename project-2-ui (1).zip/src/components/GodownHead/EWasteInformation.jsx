function EWasteInformation() {
    return (
        <>E-Waste Information Component</>
    );
}

export default EWasteInformation;