import SubHeader from "../../shared/template/components/SubHeader";
import Header from '../../shared/template/Header';
import Footer from '../../shared/template/Footer';
import { Switch, Route } from 'react-router-dom'

import GodownHeadHome from './GodownHeadHome';
import Profile from './Profile';
import CallMessageWithCollector from './CallMessageWithCollector';
import EWasteInformation from './EWasteInformation';
import History from './History';
import ProductsFromCollector from "./ProductsFromCollector";

const GodownHead = () => {

    return (
        <>
            <div>
                <Header />
                <SubHeader />
                <Switch>
                    <Route path="/home/godownHead" component={GodownHeadHome} exact />
                    <Route path="/home/godownHead/profile" component={Profile} />
                    <Route path="/home/godownHead/e-wasteInformation" component={EWasteInformation} />
                    <Route path="/home/godownHead/call-messageWithCollector" component={CallMessageWithCollector} />
                    <Route path="/home/godownHead/history" component={History} />
                    <Route path="/home/godownHead/productsFromCollector" component={ProductsFromCollector} />
                </Switch>
                <Footer />
            </div>
        </>
    );
}

export default GodownHead