import { useHistory, useLocation } from 'react-router-dom'

function GodownHeadHome() {

    const history = useHistory()
    const location = useLocation()

    const navigateToProfile = (subMenu) => {
        console.log(location.pathname.split('/', 3)[2]);
        let role = location.pathname.split('/', 3)[2]
        history.push('/home/' + role + '/' + subMenu)
    }

    return (
        <>
            <div className="row text-center" id="users">

                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('profile')}>Profile</a></h3>
                        </div>
                    </div>
                </div>

                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('call-messageWithCollector')}>Call/Message with collector</a></h3>
                        </div>
                    </div>
                </div>
                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('productsFromCollector')}>Products From Collector</a></h3>
                        </div>
                    </div>
                </div>
            </div>

            <div className="row text-center" id="cameras">

                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('history')}>History</a></h3>
                        </div>
                    </div>
                </div>

                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">

                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('e-WasteInformation')}>E-wasteInformation</a></h3>
                        </div>
                    </div>
                </div>

            </div>
        </>
    );
}

export default GodownHeadHome;