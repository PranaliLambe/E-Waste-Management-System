import ProductGrid from "../../shared/template/components/ProductGrid";
import React from 'react'
import { _getAllRejectedProductsFromCollectorByGodownId } from "../../services/product/product.service";

function ProductsFromCollector() {
    const [allProduct, setAllProduct] = React.useState([])

    React.useEffect(() => {
        getAllRejectedProductsFromCollectorByGodownId(JSON.parse(localStorage.getItem('USER')).USERID)
    }, [])

    const getAllRejectedProductsFromCollectorByGodownId = (godownId) => {
        _getAllRejectedProductsFromCollectorByGodownId(godownId).then(result => setAllProduct(result.data))
    }

    return (
        <>
            <div class="container">
                <ProductGrid allProduct={allProduct} gridType="ProductsFromCollector" />
            </div>
        </>
    );
}

export default ProductsFromCollector;
