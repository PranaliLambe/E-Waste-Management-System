function History() {
    return (
        <>History Component</>
    );
}

export default History;