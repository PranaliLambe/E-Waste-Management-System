import ProductGrid from "../../shared/template/components/ProductGrid";
import React from 'react'
import { useHistory } from 'react-router-dom'
import { _addToCart, _getAllProduct } from "../../services/product/product.service";

function Products() {
    const [allProduct, setAllProduct] = React.useState([])
    const history = useHistory()

    React.useEffect(() => {
        _getAllProduct().then(result => setAllProduct(result.data))
    }, [])

    const setSubmit = (buttonLabel, productId, userId) => {
        if (buttonLabel === 'AddToCart') {
            _addToCart(productId, userId)
                .then(result => {
                    console.log(result)
                })
        } else if (buttonLabel === 'BuyNow') {
            history.push('/home/user/payment')
        }
    }

    return (
        <>
            <div class="container">
                <div class="row2 text-center" id="cameras">
                    <ProductGrid allProduct={allProduct}
                        setSubmit={(buttonLabel, productId, userId) => setSubmit(buttonLabel, productId, userId)}
                        gridType="Products" />
                </div>
            </div>
        </>
    );
}

export default Products;