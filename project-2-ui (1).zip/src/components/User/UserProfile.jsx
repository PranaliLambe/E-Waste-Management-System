const UserProfile = () => {
    return (
        <>
            User Profile
        </>
    )
}

export default UserProfile