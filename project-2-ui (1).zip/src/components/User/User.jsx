import SubHeader from "../../shared/template/components/SubHeader";
import Header from '../../shared/template/Header';
import Footer from '../../shared/template/Footer';
import { Switch,Route } from 'react-router-dom'

import UserHome from './UserHome';
import Profile from './Profile';
import NearByCenters from './NearByCentres';
import Orders from './Orders';
import Cart from './Cart';
import Products from './Products';
import WishList from './WishList';
import SellingProduct from "./SellingProduct";
import Payment from "./Payment";


const User = () => {

    return (
        <>
            <div>
                <Header />
                <SubHeader />
                <Switch>
                    <Route path="/home/user" component={UserHome} exact />
                    <Route path="/home/user/profile" component={Profile} />
                    <Route path="/home/user/nearByCenter" component={NearByCenters} />
                    <Route path="/home/user/orders" component={Orders} />
                    <Route path="/home/user/wishlist" component={WishList} />
                    <Route path="/home/user/cart" component={Cart} />
                    <Route path="/home/user/products" component={Products} />
                    <Route path="/home/user/payment" component={Payment} />
                    <Route path="/home/user/selling-product" component={SellingProduct} />
                </Switch>
                <Footer />
            </div>

        </>
    );
}

export default User