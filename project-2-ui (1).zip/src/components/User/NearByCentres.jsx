
import Ganeshnagar from "./NearByCentres/Ganeshnagar";
import { Switch,Route } from 'react-router-dom'
import NearByCentersHome from "./NearByCentersHome";
import Vishrambag from "./NearByCentres/Vishrambag";

function NearByCenters() {
    return (
        <>
        
        <Switch>
                    <Route path="/home/user/nearByCenter" component={NearByCentersHome} exact />
                    <Route path="/home/user/nearByCenter/ganeshnagar" component={Ganeshnagar} />
                    <Route path="/home/user/nearByCenter/vishrambag" component={Vishrambag} />

        </Switch>
            
        </>
    );
}

export default NearByCenters;