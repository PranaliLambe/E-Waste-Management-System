import { useHistory, useLocation } from 'react-router-dom'

function UserHome() {

    const history = useHistory()
    const location = useLocation()

    const navigateToProfile = (subMenu) => {
        console.log(location.pathname.split('/', 3)[2]);
        let role = location.pathname.split('/', 3)[2]
        history.push('/home/' + role + '/' + subMenu)
    }

    return (
        <>
            <div className="row text-center" id="users">
                
                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('profile')}>Profile</a></h3>
                        </div>
                    </div>
                </div>

                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('nearByCenter')}>Near by centres</a></h3>
                        </div>
                    </div>
                </div>

                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('wishlist')}>Wishlist</a></h3>
                        </div>
                    </div>
                </div>
            </div>

            <div className="row text-center" id="cameras">
                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('orders')}>Orders</a></h3>
                        </div>
                    </div>
                </div>

                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('products')}>Products</a></h3>
                        </div>
                    </div>
                </div>

                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('cart')}>Cart</a></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row text-center" id="users">
                <div className="col-md-3 col-sm-6 home-feature">
                    <div className="thumbnail">
                        <div className="caption">
                            <h3><a role="button" className="btn btn-primary btn-block" onClick={() => navigateToProfile('selling-product')}>Selling Product</a></h3>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default UserHome;