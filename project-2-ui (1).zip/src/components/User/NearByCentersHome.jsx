import { useHistory, useLocation } from 'react-router-dom'

function NearByCentersHome() {

    const history = useHistory()
    const location = useLocation()

    const navigateToProfile = (subMenu) => {
        console.log(location.pathname.split('/', 3)[2]);
        let role = location.pathname.split('/', 3)[2]
        history.push('/home/' + role + '/' + subMenu)
    }

    return (
        <>
        <div class="container">
                <div class="row2 text-center" id="users">
                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a role="button" class="btn btn-primary btn-block" onClick={() => navigateToProfile('nearByCenter/ganeshnagar')}>Ganeshnagar</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a role="button" class="btn btn-primary btn-block"onClick={() => navigateToProfile('nearByCenter/vishrambag')}>Vishrambag</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Dhamani</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Sanjaynagar</a></h3>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row2 text-center" id="cameras">
                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Yashwantnagar</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Bamnoli</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Sangliwadi</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Kasbe Digraj</a></h3>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row2 text-center" id="cameras">
                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Khanbhag</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Haripur</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Limaye Mala</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 home-feature">
                        <div class="thumbnail">
                            <div class="caption">
                                <h3><a href="" role="button" class="btn btn-primary btn-block">Madhavnagar</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default NearByCentersHome;