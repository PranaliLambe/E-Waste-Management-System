import React, { useEffect } from 'react';
import WishListForm from './WishListForm';
import {_getAllProductToWishlistByUserId}  from '../../services/product/product.service';

const WishList = () => {

    const [allWishlistProduct, setAllWishlistProduct] = React.useState([])
    const [showResult, setShowResult] = React.useState(false)

    useEffect(() => {
        _getAllProductToWishlistByUserId(JSON.parse(localStorage.getItem('USER')).USERID)
            .then(result => {
                setAllWishlistProduct(result.data)
                setShowResult(false)
            })
    }, [showResult])

    return (
        <div>
            <div className="row">
                <div className="col-md-3">
                    <WishListForm setShowResult={(value) => setShowResult(value)} />
                </div>
                <div className="col-md-9">
                    <table className="table table-hover">
                        <thead>
                            <tr>
                                <th>Name of Product</th>
                                <th>Prize Expected</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                allWishlistProduct && allWishlistProduct.map((product, index) => (
                                    <tr key={index}>
                                        <td>{product.name}</td>
                                        <td>{product.expectedPrize}</td>
                                        <td>{product.quentity}</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
            </div>
            <br />
            <br />
            <br/>
            <br />
        </div>
    );
}

export default WishList;
