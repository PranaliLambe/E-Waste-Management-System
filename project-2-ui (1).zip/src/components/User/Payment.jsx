import { FormGroup, RadioGroup, FormControlLabel, Checkbox, Radio } from '@mui/material'
import React from 'react'
import { useDispatch } from 'react-redux'
import { showNotification } from '../../store/action/NotificationAction'

function Payment() {
    const user = JSON.parse(localStorage.getItem('USER'))
    const dispatch = useDispatch()
    const [payment, setPayment] = React.useState({
        isPayOnDelivary: false,
        acceptedTermsAndCondition: false
    })

    const handleChange = (event) => {
        console.log(event);
        const { name, value } = event.target
        setPayment({
            ...payment,
            [name]: value
        })
    }

    const handleCheckboxChange = (event) => {
        const { name, checked } = event.target
        console.log(name, checked);
        setPayment({
            ...payment,
            [name]: checked
        })
    }

    const placeYourOrder = () => {

        if (!payment.acceptedTermsAndCondition || !payment.isPayOnDelivary) {
            if (!payment.acceptedTermsAndCondition && !payment.isPayOnDelivary) {
                dispatch(showNotification('Please Select Pay On Delivary & Accept Terms and Condition', 'error'))
            } else if (!payment.acceptedTermsAndCondition) {
                dispatch(showNotification('Please Accept Terms and Condition', 'error'))
            } else if (!payment.isPayOnDelivary) {
                dispatch(showNotification('Please Select Pay On Delivary', 'error'))
            }
        } else if (payment.acceptedTermsAndCondition && payment.isPayOnDelivary) {
            // Call service
        }
    }

    return (
        <div class="container">
            <h2>Payment Method</h2>

            <div style={{ 'display': 'flex' }}>
                <div className="border border-secondary p-4 col-md-7">
                    <div style={{ 'display': 'flex' }}>
                        <div className="col-md-6">
                            <RadioGroup value={payment.isPayOnDelivary}
                                name="isPayOnDelivary"
                                onChange={handleChange}>
                                <FormControlLabel value={true} control={<Radio />}
                                    label="Pay on Delivery"
                                    sx={{ '& .MuiSvgIcon-root': { fontSize: 22 } }} />
                            </RadioGroup>
                            <FormGroup value={payment.acceptedTermsAndCondition}
                                onChange={handleCheckboxChange}>
                                <FormControlLabel control={<Checkbox name="acceptedTermsAndCondition" checked={payment.acceptedTermsAndCondition} />}
                                    label="Accept Terms And Condition"
                                    sx={{ '& .MuiSvgIcon-root': { fontSize: 22 } }} />
                            </FormGroup>
                        </div>
                        <div className="col-md-6">
                            <h4><b>Shipping address</b></h4>
                            <div>{user.FIRSTNAME} {user.LASTNAME}</div>
                            <div>{user.LOCAL_ADDRESS_LINE}</div>
                            <div>{user.LOCAL_CITY}, {user.LOCAL_STATE} {user.LOCAL_POSTELCODE}</div>
                            <div>{user.LOCAL_COUNTRY}</div>
                            <div>Phone : {user.CONTACTNUMBER}</div>
                        </div>
                    </div>
                </div>
                <div className="col-md-1"></div>
                <div className="col-md-4 border border-secondary p-4">
                    <div>
                        <bitton className="btn btn-warning w-100" onClick={placeYourOrder}>
                            Place your order
                        </bitton>
                        <h4><b>Order Summary</b></h4>

                        <div style={{ 'display': 'flex', 'justifyContent': 'space-between' }}>
                            Items:
                            <div >₹1,199.00</div>
                        </div>
                        <div style={{ 'display': 'flex', 'justifyContent': 'space-between' }}>
                            Delivery:
                            <div>₹40.00</div>
                        </div>
                        <div style={{ 'display': 'flex', 'justifyContent': 'space-between' }}>
                            Total:
                            <div>₹1,239.00</div>
                        </div>
                        <div style={{ 'display': 'flex', 'justifyContent': 'space-between' }}>
                            Promotion Applied:
                            <div>₹1,239.00</div>
                        </div>
                        <hr />
                        <div style={{ 'display': 'flex', 'justifyContent': 'space-between' }}>
                            Order Total:
                            <div>₹1,199.00</div>
                        </div>
                    </div>
                </div>
            </div>
            <br />
            <br />
            <br />
            <br />
        </div>
    );
}

export default Payment;
