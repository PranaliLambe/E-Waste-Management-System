import { _getAllAddToCartProductsById } from "../../services/product/product.service"
import React from 'react'
import ProductGrid from "../../shared/template/components/ProductGrid"
import { useHistory } from 'react-router-dom'

function Cart() {
    const [allProduct, setAllProduct] = React.useState([])
    const history = useHistory()
    React.useEffect(() => {
        _getAllAddToCartProductsById(JSON.parse(localStorage.getItem('USER')).USERID)
            .then(result => setAllProduct(result.data))
    }, [])

    const setSubmit = (productId, userId) => {
        console.log(productId, userId);
        history.push('/home/user/payment')
    }

    return (
        <>
            <div class="container">
                <div class="row2 text-center" id="cameras">
                    <ProductGrid allProduct={allProduct} gridType="Cart"
                        setSubmit={(productId, userId) => setSubmit(productId, userId)} />
                </div>
            </div>
        </>
    );
}

export default Cart;