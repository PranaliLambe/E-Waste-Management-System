import React from 'react'

const Orders = () => {
  return (
    <div>
      Orders 
      {/* // ToDo - list of products where payment is confirmed */}

    </div>
  )
}

export default Orders