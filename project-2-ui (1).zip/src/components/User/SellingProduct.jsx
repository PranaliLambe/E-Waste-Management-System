import { useForm } from 'react-hook-form'
import { _createProduct, _getAllNearByCenter } from '../../services/product/product.service'
import Select from '@mui/material/Select'
import MenuItem from '@mui/material/MenuItem'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import Box from '@mui/material/Box'
import React from 'react';

function SellingProduct() {

    const { register, handleSubmit, formState: { errors }, } = useForm()
    const [nearByCenter, setNearByCenter] = React.useState([])

    const onSubmit = (data) => {
        data.userId = JSON.parse(localStorage.getItem('USER')).USERID
        console.log(data)
        _createProduct(data).then(result => {
            console.log(result)
        })
    }

    React.useEffect(() => {
        _getAllNearByCenter().then(result => {
            console.log(result.data);
            setNearByCenter(result.data)
        })
    }, [])

    return (
        <>
            <div className="container-fluid decor_bg" id="content">
                <div className="row4">
                    <div className="container">
                        <div className="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                            <h2>Selling Product</h2>
                            <form>
                                <div className="form-group">
                                    <input className="form-control" placeholder="Product Name"
                                        name="name"
                                        {...register('name', { required: true })} />
                                    {errors.name && <p className="error">Product Name is required.</p>}
                                </div>
                                <div className="form-group">
                                    <input className="form-control" placeholder="Price"
                                        name="prize"
                                        {...register('prize', { required: true })} />
                                    {errors.prize && <p className="error">Prize is required.</p>}
                                </div>
                                <div className="form-group">
                                    <input className="form-control" placeholder="How many years used?"
                                        name="numberOfYearsUsed"
                                        {...register('numberOfYearsUsed', { required: true })} />
                                    {errors.numberOfYearsUsed && <p className="error">Number Of Years Used is required.</p>}
                                </div>

                                <Box >
                                    <FormControl className="mt-1" style={{ 'width': '230px' }}>
                                        <InputLabel id="demo-simple-select-label">Near By Center</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-label"
                                            id="demo-simple-select"
                                            {...register('nearByCenterId', { required: true })}
                                            name="nearByCenterId"
                                            label="Near By Center">
                                            {
                                                nearByCenter && nearByCenter.map((center, index) => (
                                                    <MenuItem value={center.ID} key={index}>
                                                        {center.NAME}
                                                    </MenuItem>
                                                ))
                                            }
                                        </Select>
                                        {errors.nearByCenterId && <p className="error">Near By Center is required.</p>}
                                    </FormControl>
                                </Box>

                                <div className="form-group mt-4">
                                    <input className="form-control" placeholder="Product Photo"
                                        name="photo" type="file"
                                        {...register('photo', { required: true })} />
                                    {errors.photo && <p className="error">Product Photo is required.</p>}
                                </div>

                                <button type="submit" name="submit" className="mt-4 btn btn-primary"
                                    onClick={handleSubmit(onSubmit)}>
                                    Submit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <br />
                <br />
                <br />
                <br />
                <br />
            </div>
        </>
    );
}

export default SellingProduct;
