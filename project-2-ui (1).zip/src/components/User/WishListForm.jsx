import React from 'react';
import TextField from '@mui/material/TextField'
import Select from '@mui/material/Select'
import MenuItem from '@mui/material/MenuItem'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import { _addProductToWishlistByUserId, _getAllNearByCenter } from '../../services/product/product.service';
import { useDispatch } from 'react-redux'
import { showNotification } from '../../store/action/NotificationAction';

const WishListForm = ({ setShowResult }) => {

    const dispatch = useDispatch()

    const [currentWishList, setCurrentWishList] = React.useState({
        name: '',
        expectedPrize: '',
        quentity: '',
        nearByCenter: '',
        userId: JSON.parse(localStorage.getItem('USER')).USERID
    })

    const [nearByCenter, setNearByCenter] = React.useState([])

    React.useEffect(() => {
        _getAllNearByCenter().then(result => {
            console.log(result.data);
            setNearByCenter(result.data)
        })
    }, [])

    const handleChange = (event) => {
        const { name, value } = event.target
        setCurrentWishList({
            ...currentWishList,
            [name]: value
        })
    }

    const addToWishList = () => {
        console.log(currentWishList)
        _addProductToWishlistByUserId(currentWishList).then(result => {
            if (result.status === 201) {
                setShowResult(true)
                clearForm()
                dispatch(showNotification('Product added to wishlist', 'success'))
            }
        })
    }

    const clearForm = () => {
        setCurrentWishList({
            name: '',
            expectedPrize: '',
            quentity: '',
            nearByCenter: '',
            userId: JSON.parse(localStorage.getItem('USER')).USERID
        })
    }

    return (
        <div>
            <div className="col-md-12">
                <TextField label="Name" variant="standard" className="w-100"
                    value={currentWishList.name}
                    name="name"
                    onChange={handleChange} />
                <TextField label="Expected Prize" variant="standard" className="w-100"
                    value={currentWishList.expectedPrize}
                    name="expectedPrize"
                    onChange={handleChange} />
                <TextField label="Quentity" variant="standard" className="w-100"
                    value={currentWishList.quentity}
                    name="quentity"
                    onChange={handleChange} />
                <Box sx={{ minWidth: 120 }}>
                    <FormControl className="w-100 mt-4">
                        <InputLabel id="demo-simple-select-label">Near By Center</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={currentWishList.nearByCenter}
                            name="nearByCenter"
                            label="Near By Center"
                            onChange={handleChange}>
                            {
                                nearByCenter && nearByCenter.map((center, index) => (
                                    <MenuItem value={center.ID} key={index}>
                                        {center.NAME}
                                    </MenuItem>
                                ))
                            }
                        </Select>
                    </FormControl>
                </Box>
                <Button className="w-100 mt-4" variant="contained"
                    onClick={addToWishList}>
                    Add To WishList
                </Button>
            </div>
        </div>
    );
}

export default WishListForm;
