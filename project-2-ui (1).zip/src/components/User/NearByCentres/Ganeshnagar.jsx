function Ganeshnagar() {
    return (
        <>
        {/* ganeshnagar component */}
        <div class="container">
			<h2>Your Profile</h2>          
			<table class="table table-condensed">
				<thead>
					<tr>
						<th>Title</th>
						<th>Information</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Name of Collection Centre</td>
						<td>Magnus E-Waste Recycling Centre</td>
					</tr>
					<tr>
						<td>Address</td>
						<td>Lane No. 5, Near Horizon Hospital, Ganeshnagar, Sangli.</td>
					</tr>
					<tr>
						<td>Name of Collector</td>
						<td>Mr. Sandesh M. Patil</td>
					</tr>
					<tr>
						<td>Contact Number</td>
						<td>9876543210</td>
					</tr>
					
				</tbody>
			</table>
			<div class="container-fluid decor_bg" id="content">
            <div class="row">
                <div class="container">
                    <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                        <h2>Message for Collector</h2>
                        <form  action="signup_script.html" method="POST">
                            <div class="form-group">
                                <input class="form-control" placeholder="Add Message" name="addmessage"  required/>
                            </div>
                            
                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
		</div>
        
		
        </>
    );
}

export default Ganeshnagar;