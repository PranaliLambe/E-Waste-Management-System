function Vishrambag() {
    return (
        <>vishrambag component
        </>
    );
}

export default Vishrambag;